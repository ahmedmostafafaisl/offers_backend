<?php

return [
    'dashboard' => 'لوحة التحكم',
    'overview' => 'نظرة عامة',

    // sidebar
    'main_menu' => 'القائمة الرئيسية',
    'users' => 'المستخدمين',
    'roles' => 'الأدوار',
    'permissions' => 'الصلاحيات',

    'categories' => 'التصنيفات',
    'offers' => 'العروض',
    'sliders' => 'السلايدر',

    'plans' => 'الباقات',
    'plan_features' => 'مميزات الباقات',
    'subscriptions' => 'الاشتراكات',

    'offer_reports' => 'بلاغات العروض',
    'offer_complaints' => 'شكاوى العروض',
    'pending_verifications' => 'طلبات التحقق المعلقة',

    // topbar
    'logout' => 'تسجيل خروج',
    'language' => 'اللغة',
    'english' => 'الإنجليزية',
    'arabic' => 'العربية',

    // cards/stats
    'stats' => [
        'users' => 'المستخدمين',
        'offers' => 'العروض',
        'categories' => 'التصنيفات',
        'sliders' => 'السلايدر',
    ],

    // misc
    'welcome' => 'مرحبًا',
    'welcome_hint' => 'استخدم القائمة لإدارة الموديولات (CRUD).',

    // common
    'create' => 'إضافة',
    'edit' => 'تعديل',
    'back' => 'رجوع',
    'search' => 'بحث...',
];
