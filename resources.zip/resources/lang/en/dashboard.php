<?php

return [
    'dashboard' => 'Dashboard',
    'overview' => 'Overview',

    // sidebar
    'main_menu' => 'MAIN MENU',
    'users' => 'Users',
    'roles' => 'Roles',
    'permissions' => 'Permissions',

    'categories' => 'Categories',
    'offers' => 'Offers',
    'sliders' => 'Sliders',

    'plans' => 'Plans',
    'plan_features' => 'Plan Features',
    'subscriptions' => 'Subscriptions',

    'offer_reports' => 'Offer Reports',
    'offer_complaints' => 'Offer Complaints',
    'pending_verifications' => 'Pending Verifications',

    // topbar
    'logout' => 'Logout',
    'language' => 'Language',
    'english' => 'English',
    'arabic' => 'Arabic',

    // cards/stats
    'stats' => [
        'users' => 'Users',
        'offers' => 'Offers',
        'categories' => 'Categories',
        'sliders' => 'Sliders',
    ],

    // misc
    'welcome' => 'Welcome',
    'welcome_hint' => 'Use the sidebar to manage modules (CRUD).',

    // common
    'create' => 'Create',
    'edit' => 'Edit',
    'back' => 'Back',
    'search' => 'Search...',
];
