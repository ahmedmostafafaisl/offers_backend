@php
    $title = 'Edit Plan';
    $backUrl = route('dashboard.plans.index');
    $action = route('dashboard.plans.update', $row->id);
    $method = 'PUT';
    $fields = view('dashboard.plans.fields', ['row' => $row])->render();
@endphp
@include('dashboard.crud.form', compact('title', 'backUrl', 'action', 'method', 'fields'))
