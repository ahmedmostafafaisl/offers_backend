@php
    $title = 'Plans';
    $columns = ['ID', 'Name', 'Monthly Price', 'Annually Price', 'Created'];
@endphp

@include('dashboard.crud.index', [
    'title' => $title,
    'breadcrumb' => 'Overview / Plans',
    'createUrl' => route('dashboard.plans.create'),
    'columns' => $columns,
    'rows' => $rows,
    'filtersView' => null,
    'editUrl' => fn($r) => route('dashboard.plans.edit', $r->id),
    'deleteUrl' => fn($r) => route('dashboard.plans.destroy', $r->id),
    'renderRow' => function ($r) {
        $monthly = $r->monthly_price ?? 0;
        $annually = $r->annually_price ?? 0;
        return "
        <td>{$r->id}</td>
        <td>{$r->name}</td>
        <td>{$monthly}</td>
        <td>{$annually}</td>
        <td>" . optional($r->created_at)->format('d/m/Y') . "</td>
      ";
    }
])
