@php
    $title = 'Create Plan';
    $backUrl = route('dashboard.plans.index');
    $action = route('dashboard.plans.store');
    $method = 'POST';

    // ✅ fields partial
    $fields = view('dashboard.plans.fields', ['row' => null])->render();
@endphp

@include('dashboard.crud.form', compact('title', 'backUrl', 'action', 'method', 'fields'))
