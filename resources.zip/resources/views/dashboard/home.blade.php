@extends('layouts.dashboard')

@section('title', __('dashboard.dashboard'))
@section('page_title', __('dashboard.overview'))

@section('content')
    <div class="w-100"> {{-- ✅ مهم: Wrapper واحد يمنع flex من تقسيم الصفحة --}}
        <div class="row g-3">
            <div class="col-md-3">
                <div class="card-soft p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">{{ __('dashboard.stats.users') }}</div>
                            <div class="h4 mb-0">{{ \App\Models\User::count() }}</div>
                        </div>
                        <div class="rounded-circle d-flex align-items-center justify-content-center"
                            style="width:44px;height:44px;background:#FFF4CC;color:#7a5b00;">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card-soft p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">{{ __('dashboard.stats.offers') }}</div>
                            <div class="h4 mb-0">{{ \App\Models\Offer::count() }}</div>
                        </div>
                        <div class="rounded-circle d-flex align-items-center justify-content-center"
                            style="width:44px;height:44px;background:#FFF4CC;color:#7a5b00;">
                            <i class="bi bi-bag"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card-soft p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">{{ __('dashboard.stats.categories') }}</div>
                            <div class="h4 mb-0">{{ \App\Models\Category::count() }}</div>
                        </div>
                        <div class="rounded-circle d-flex align-items-center justify-content-center"
                            style="width:44px;height:44px;background:#FFF4CC;color:#7a5b00;">
                            <i class="bi bi-tags"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card-soft p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">{{ __('dashboard.stats.sliders') }}</div>
                            <div class="h4 mb-0">{{ \App\Models\Slider::count() }}</div>
                        </div>
                        <div class="rounded-circle d-flex align-items-center justify-content-center"
                            style="width:44px;height:44px;background:#FFF4CC;color:#7a5b00;">
                            <i class="bi bi-images"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-soft p-4 mt-3">
            <h5 class="mb-1">{{ __('dashboard.welcome') }}</h5>
            <div class="text-muted">{{ __('dashboard.welcome_hint') }}</div>
        </div>
    </div>
@endsection
